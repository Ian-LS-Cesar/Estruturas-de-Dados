package exceptions;

public class FullListException extends RuntimeException {
    public FullListException(String errorMessage){
        super(errorMessage);
    }

}
